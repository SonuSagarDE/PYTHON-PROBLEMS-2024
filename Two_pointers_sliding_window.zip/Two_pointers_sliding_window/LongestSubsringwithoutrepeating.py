def longestsubstring(arr):
    n = len(arr)
    l=0
    r=0
    m= {}
    max_len=0
    length = 0

    while (r<n):
      if arr[r] in m:
          if m[arr[r]] >=l:
              l  = m[arr[r]] +1
      length = r-l+1
      max_len = max(max_len, length)
      m[arr[r]]= r
      r= r+1
    return max_len



arr = ['a','k', 's','k','v', 'h', 'g','h','m','l', 's', 'i', 'u', 'o', 'h']

print(longestsubstring(arr))