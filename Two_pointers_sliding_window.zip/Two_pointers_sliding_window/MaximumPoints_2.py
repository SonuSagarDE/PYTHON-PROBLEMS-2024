def max_points(arr, k):
    n = len(arr)

    lsum =sum(arr[0:k])

    max_sum = lsum

    for i in range(k,n):
        lsum = lsum + arr[i]
        lsum = lsum - arr[i-k]
        max_sum = max(max_sum, lsum)

    return max_sum



arr = [10,3,19,280,33,90,5,60,90]

print(max_points(arr,3))
