def max_points(arr, k):
    n = len(arr)

    lsum =0
    rsum =0
    max_sum = 0

    for i in range(0,k):
        lsum = lsum + arr[i]
        max_sum = lsum

    r=n-1

    for i in range(k-1, -1, -1):
        lsum = lsum - arr[i]
        rsum = rsum + arr[r]
        r=r-1
        max_sum = max(max_sum, lsum+rsum)

    return max_sum



arr = [10,3,19,28,33,9,5,60,90]

print(max_points(arr,3))

